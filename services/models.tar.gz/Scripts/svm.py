def make_svm_model():
    